<?php
 header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); 
 header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT"); 
 header("Cache-Control: no-store, no-cache, must-revalidate"); 
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache"); // HTTP/1.0
?>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/default.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="conf/validator.js"></script>
</head>
<body>
  
    <h1 class="title">SIMRS KhanzaHMS</h1>
    <div id="post">
       <b><br>Dikembangkan Oleh : <br>
		&nbsp;&nbsp;&nbsp;&nbsp;Khanza.Soft Media<br>
            Email : <br> 
			  &nbsp;&nbsp;&nbsp;&nbsp;Khanza.Media@yahoo.com,akhi_tangguh@yahoo.com<br>
            Skype : <br> 
			  &nbsp;&nbsp;&nbsp;&nbsp;khanza.media<br> 			 
			<br> Programmer : Windiarto Nugroho
			<br> HP : 08562675039
	   </b>
		
    </div>

</body>

