
<div id="post">
        <b><br>
         <font size='3' face='Comic Sans Ms' color='#ABABAB'>Dikembangkan Oleh : </font><br>
         &nbsp;&nbsp;&nbsp;&nbsp;<font size='3' face='Comic Sans Ms' color='#ABABAB'>Khanza.Soft Media</font><br>
         <font size='3' face='Comic Sans Ms' color='#ABABAB'>Email : </font><br>
         &nbsp;&nbsp;&nbsp;&nbsp;<font size='3' face='Comic Sans Ms' color='#ABABAB'>khanza_media@yahoo.com</font><br>
         <font size='3' face='Comic Sans Ms' color='#ABABAB'>Alamat : </font><br>
         &nbsp;&nbsp;&nbsp;&nbsp; <font size='3' face='Comic Sans Ms' color='#ABABAB'>Sekarsuli RT.03/RW.03 Kec.Klaten Utara, Klaten Jawa Tengah</font><br>

	</b>

    </div>

      